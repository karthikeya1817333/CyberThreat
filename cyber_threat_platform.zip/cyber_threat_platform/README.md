# Cybersecurity Threat Detection – Big-Data Analytics + ML Platform

End-to-end pipeline on a **synthetic** 12,000-record network-traffic dataset:
dataset generation → analytics (Spark or pandas fallback) → Random Forest → Isolation Forest → security alerts → charts → Streamlit dashboard.

## Quick start (results already included)
```bash
pip install -r requirements.txt
./launch_dashboard.sh            # or: streamlit run dashboard/app.py
```
Rebuild everything from scratch (≈15 s) and re-verify:
```bash
./run_all.sh --no-dashboard      # pipeline + verification + dashboard smoke test
```
`python run_pipeline.py --clean` runs the pipeline only. `USE_SPARK=0` forces the pandas path.

## Layout
```
run_pipeline.py          orchestrates all stages
src/                     generate_dataset, analytics, features, ml_models, alerts, visualize, static_report
dashboard/app.py         Streamlit app (reads results/ only)   dashboard/loaders.py  data layer
tests/verify_results.py  53 independent checks (recomputes model metrics from the saved model)
tests/smoke_dashboard.py runs app.py against real results with a stubbed `streamlit` module
data/network_traffic.csv generated dataset            models/   saved Random Forest + test split ids
results/analytics|ml|anomalies|alerts|visualizations|dashboard_static
logs/                    pipeline_execution.log, terminal_output.log, verification.log, dashboard_smoke_test.log, environment.txt
screenshots/             see screenshots/README.txt (static rendering, NOT Streamlit)
```

## What was actually executed when this ZIP was built
| Item | Status |
|---|---|
| Dataset (12,000 rows, 6 traffic classes) | Executed |
| Analytics | Executed with the **pandas fallback** (`engine: pandas-fallback` in `analytics_results.json`) |
| Spark / Spark SQL / `spark_analytics.parquet` | **NOT executed** – pyspark/pyarrow unavailable in the build sandbox. The Spark code path in `src/analytics.py` is untested; it activates automatically if pyspark + Java are installed. No Parquet file is shipped. |
| Random Forest, Isolation Forest, alerts, charts | Executed; every metric comes from the run |
| Streamlit dashboard | **Not launched** in the build sandbox (Streamlit not installable). `app.py` was executed against the real results with a stubbed `streamlit` module (`logs/dashboard_smoke_test.log`) – this checks the code path and that KPIs equal the files, but is not a rendered UI. |
| Dashboard screenshots | Static-HTML captures only (see `screenshots/README.txt`) |

## Reading the ML results honestly
* Data is synthetic and attack families are far more separable than real traffic. Scores near 99.9 % say little about real-world performance.
* The split is **grouped by source IP** (no IP in both train and test). An earlier version with a random split scored exactly 1.0000 – a sign of source-fingerprint leakage – so it was replaced.
* Per-IP aggregate features (connections per source, distinct ports probed, …) drive much of the accuracy. `model_metrics.json → ablation_record_level_features_only` trains on single-record features only and scores noticeably lower.
* Isolation Forest uses `contamination=0.10`, so its ~10 % anomaly rate is a configured assumption, not a discovery. It is unsupervised; labels are used only for the reported ground-truth check.
* Alert threat score = 100·(0.65·P(malicious, out-of-fold RF) + 0.35·normalised Isolation-Forest score); severity: Critical ≥ 85, High ≥ 70, Medium ≥ 50, Low < 50. These weights/thresholds are design choices, not tuned values.
* Alerts include `actual_category` purely for evaluation transparency; a real deployment would not have it.

## Spark path (optional)
Install Java 17 + `pip install pyspark pyarrow`, then `python run_pipeline.py --clean`. If Spark runs, `results/analytics/spark_analytics.parquet/` is written and Spark SQL queries are logged.
