"""Reads ONLY generated files under results/. No hardcoded values."""
import json
from pathlib import Path
import pandas as pd

RESULTS = Path(__file__).resolve().parents[1] / "results"
REQUIRED = ["analytics/dataset_summary.json", "analytics/attack_distribution.csv", "ml/model_metrics.json",
            "ml/confusion_matrix.csv", "anomalies/anomaly_summary.json", "alerts/security_alerts.csv",
            "alerts/severity_summary.json"]


def missing_files():
    return [f for f in REQUIRED if not (RESULTS / f).exists()]


def _j(rel): return json.loads((RESULTS / rel).read_text())
def _c(rel, **kw): return pd.read_csv(RESULTS / rel, **kw)


def load_all():
    return {
        "summary": _j("analytics/dataset_summary.json"),
        "analytics": _j("analytics/analytics_results.json"),
        "protocols": _c("analytics/protocol_distribution.csv"),
        "attacks": _c("analytics/attack_distribution.csv"),
        "top_src": _c("analytics/top_source_ips.csv"),
        "top_dst": _c("analytics/top_destination_ips.csv"),
        "ports": _c("analytics/most_targeted_ports.csv"),
        "patterns": _c("analytics/suspicious_patterns.csv"),
        "metrics": _j("ml/model_metrics.json"),
        "cm": _c("ml/confusion_matrix.csv", index_col=0),
        "report_txt": (RESULTS / "ml/classification_report.txt").read_text(),
        "samples": _c("ml/sample_predictions.csv"),
        "anom": _j("anomalies/anomaly_summary.json"),
        "anom_df": _c("anomalies/detected_anomalies.csv"),
        "alerts": _c("alerts/security_alerts.csv"),
        "sev": _j("alerts/severity_summary.json"),
    }


def suspicious_ips(alerts, n=10):
    g = (alerts.groupby("src_ip").agg(alerts=("alert_id", "count"), max_threat_score=("threat_score", "max"),
                                      avg_threat_score=("threat_score", "mean"),
                                      categories=("attack_category", lambda s: ", ".join(sorted(set(s)))))
         .reset_index().sort_values(["max_threat_score", "alerts"], ascending=False).head(n))
    g["avg_threat_score"] = g.avg_threat_score.round(2)
    return g
