#!/usr/bin/env bash
# Launch the Streamlit dashboard on the results that ship in this ZIP (no re-run needed).
cd "$(dirname "$0")" && streamlit run dashboard/app.py
