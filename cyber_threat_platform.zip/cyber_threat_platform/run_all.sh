#!/usr/bin/env bash
# Full rebuild + verification + dashboard.  Usage: ./run_all.sh [--no-dashboard]
set -e
cd "$(dirname "$0")"
python3 run_pipeline.py --clean 2>&1 | tee logs/terminal_output.log
python3 tests/verify_results.py
python3 tests/smoke_dashboard.py
[ "$1" = "--no-dashboard" ] || streamlit run dashboard/app.py
