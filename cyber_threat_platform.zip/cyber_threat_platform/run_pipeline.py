#!/usr/bin/env python3
"""Run the complete pipeline: dataset -> analytics -> ML -> anomalies -> alerts -> charts -> static report."""
import logging
import shutil
import sys
import time
from src import config
from src import generate_dataset, analytics, ml_models, alerts, visualize, static_report
from src.features import build_features


def main():
    if "--clean" in sys.argv:
        for d in (config.RESULTS, config.MODEL_DIR, config.DATA_DIR):
            shutil.rmtree(d, ignore_errors=True)
    config.ensure_dirs()
    log = logging.getLogger("pipeline"); log.setLevel(logging.INFO); log.handlers.clear()
    fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
    for h in (logging.StreamHandler(sys.stdout), logging.FileHandler(config.LOG_DIR / "pipeline_execution.log", mode="w")):
        h.setFormatter(fmt); log.addHandler(h)
    t0 = time.time()
    log.info("=== PIPELINE START (python %s) ===", sys.version.split()[0])
    df = generate_dataset.run(log)
    analytics.run(df, log)
    X = build_features(df)
    log.info("Feature matrix: %s", X.shape)
    ml_models.train_random_forest(df, X, log)
    iso = ml_models.run_isolation_forest(df, X, log)
    alerts.run(df, X, iso, log)
    visualize.run(log)
    static_report.run(log)
    log.info("=== PIPELINE COMPLETE in %.1fs ===", time.time() - t0)


if __name__ == "__main__":
    main()
