IMPORTANT – what these screenshots are
--------------------------------------
Streamlit could not be installed in the environment where this project was built (no network),
so the Streamlit UI was never rendered there and NO screenshots of it exist.

These PNGs are headless-Chromium captures of results/dashboard_static/dashboard_static.html, a static
page rendered by src/static_report.py from the SAME result files the Streamlit app reads.
They show the real generated numbers/charts, but they are not the Streamlit interface.

To capture the real dashboard on your machine:  ./launch_dashboard.sh  and take screenshots of each tab.
