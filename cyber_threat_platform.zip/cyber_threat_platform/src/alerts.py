"""Security alert generation: out-of-fold RF probabilities + Isolation-Forest score + rule evidence."""
import json
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_predict
from .config import ALERT_DIR, SEED
from .ml_models import RF_PARAMS, group_cv

SEV = [(85, "Critical"), (70, "High"), (50, "Medium"), (0, "Low")]


def severity(score):
    return next(name for thr, name in SEV if score >= thr)


def run(df, X, iso_df, log):
    # Out-of-fold, source-IP-grouped predictions: no record is scored by a model that saw its source IP.
    rf = RandomForestClassifier(**RF_PARAMS)
    proba = cross_val_predict(rf, X, df.attack_category, cv=group_cv(), groups=df.src_ip, method="predict_proba")
    classes = np.array(sorted(df.attack_category.unique()))
    pred = classes[proba.argmax(1)]
    p_mal = 1 - proba[:, list(classes).index("Benign")]
    score = np.round(100 * (0.65 * p_mal + 0.35 * iso_df.anomaly_score.values), 2)

    a = df[["timestamp", "src_ip", "dst_ip", "protocol"]].copy()
    a["record_id"] = df.record_id
    a["attack_category"] = pred; a["threat_score"] = score
    a["severity"] = [severity(s) for s in score]
    a["is_anomaly"] = iso_df.is_anomaly.values
    a["rf_confidence"] = np.round(proba.max(1), 4)
    a["actual_category"] = df.attack_category  # kept for evaluation transparency
    keep = (a.attack_category != "Benign") | a.is_anomaly
    a = a[keep].copy()

    def reason(r, x):
        parts = []
        if r.attack_category != "Benign":
            parts.append(f"Random Forest classified as {r.attack_category} (confidence {r.rf_confidence:.2f})")
        if r.is_anomaly:
            parts.append("Isolation Forest flagged statistical anomaly")
        if x.src_unique_dst_ports >= 50: parts.append(f"source probed {int(x.src_unique_dst_ports)} distinct ports")
        if x.src_failed_logins_total >= 20: parts.append(f"source has {int(x.src_failed_logins_total)} failed logins")
        if x.dst_srcs_5min >= 20: parts.append(f"destination contacted by {int(x.dst_srcs_5min)} distinct sources within 5 minutes")
        if x.src_conns_same_minute >= 10: parts.append(f"{int(x.src_conns_same_minute)} connections from source within one minute")
        return "; ".join(parts)

    Xa = X.loc[a.index]
    a["detection_reason"] = [reason(r, Xa.loc[i]) for i, r in a.iterrows()]
    a = a.sort_values(["threat_score", "timestamp"], ascending=[False, True]).reset_index(drop=True)
    a.insert(0, "alert_id", [f"ALT-{i:06d}" for i in range(1, len(a) + 1)])
    cols = ["alert_id", "timestamp", "src_ip", "dst_ip", "protocol", "attack_category", "threat_score",
            "severity", "detection_reason", "record_id", "is_anomaly", "rf_confidence", "actual_category"]
    a[cols].to_csv(ALERT_DIR / "security_alerts.csv", index=False)

    counts = a.severity.value_counts()
    summ = {"total_alerts": int(len(a)),
            "critical": int(counts.get("Critical", 0)), "high": int(counts.get("High", 0)),
            "medium": int(counts.get("Medium", 0)), "low": int(counts.get("Low", 0)),
            "severity_thresholds": {"Critical": ">=85", "High": ">=70", "Medium": ">=50", "Low": "<50"},
            "threat_score_formula": "100 * (0.65 * P(malicious, out-of-fold RF) + 0.35 * normalized IsolationForest score)",
            "alerts_by_category": {k: int(v) for k, v in a.attack_category.value_counts().items()},
            "severity_by_category": {c: {s: int(n) for s, n in g.severity.value_counts().items()}
                                     for c, g in a.groupby("attack_category")}}
    (ALERT_DIR / "severity_summary.json").write_text(json.dumps(summ, indent=2))
    log.info("Alerts generated: %s", json.dumps({k: summ[k] for k in ("total_alerts", "critical", "high", "medium", "low")}))
    return a
