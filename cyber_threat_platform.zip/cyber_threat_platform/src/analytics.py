"""Big-data analytics stage.

Primary engine: PySpark (local mode) incl. Spark SQL and Parquet output.
Fallback engine: pandas (identical output schema).  The engine actually used
is recorded in results/analytics/analytics_results.json ("engine").
Set USE_SPARK=0 to force the fallback.
"""
import json
import os
import numpy as np
import pandas as pd
from .config import ANALYTICS_DIR, DATA_CSV

AUTH_PORTS = [21, 22, 23, 3389]


def _pandas_core(df):
    total = len(df)
    proto = (df.groupby("protocol").agg(records=("record_id", "count"), total_bytes=("bytes_sent", "sum"))
             .reset_index().sort_values("records", ascending=False))
    proto["pct"] = (proto.records / total * 100).round(2)

    def top(col):
        t = (df.groupby(col).agg(connections=("record_id", "count"),
                                 total_bytes=("bytes_sent", "sum"),
                                 malicious_records=("label", lambda s: int((s == "Malicious").sum())))
             .reset_index().sort_values("connections", ascending=False).head(10))
        return t

    ports = (df.groupby("dst_port").agg(total_connections=("record_id", "count"),
                                        malicious_connections=("label", lambda s: int((s == "Malicious").sum())))
             .reset_index())
    ports["malicious_pct"] = (ports.malicious_connections / ports.total_connections * 100).round(2)
    ports = ports.sort_values(["malicious_connections", "total_connections"], ascending=False).head(15)

    att = df.attack_category.value_counts().rename_axis("attack_category").reset_index(name="records")
    att["pct"] = (att.records / total * 100).round(2)
    return total, proto, top("src_ip"), top("dst_ip"), ports, att


def _spark_core(log):
    from pyspark.sql import SparkSession  # ImportError -> fallback
    spark = (SparkSession.builder.master("local[*]").appName("CyberThreatAnalytics")
             .config("spark.ui.enabled", "false").getOrCreate())
    spark.sparkContext.setLogLevel("ERROR")
    sdf = spark.read.csv(str(DATA_CSV), header=True, inferSchema=True)
    sdf.createOrReplaceTempView("traffic")
    q = {
        "total": "SELECT COUNT(*) AS n FROM traffic",
        "proto": "SELECT protocol, COUNT(*) AS records, SUM(bytes_sent) AS total_bytes FROM traffic GROUP BY protocol ORDER BY records DESC",
        "src": "SELECT src_ip, COUNT(*) AS connections, SUM(bytes_sent) AS total_bytes, SUM(CASE WHEN label='Malicious' THEN 1 ELSE 0 END) AS malicious_records FROM traffic GROUP BY src_ip ORDER BY connections DESC LIMIT 10",
        "dst": "SELECT dst_ip, COUNT(*) AS connections, SUM(bytes_sent) AS total_bytes, SUM(CASE WHEN label='Malicious' THEN 1 ELSE 0 END) AS malicious_records FROM traffic GROUP BY dst_ip ORDER BY connections DESC LIMIT 10",
        "ports": "SELECT dst_port, COUNT(*) AS total_connections, SUM(CASE WHEN label='Malicious' THEN 1 ELSE 0 END) AS malicious_connections FROM traffic GROUP BY dst_port ORDER BY malicious_connections DESC, total_connections DESC LIMIT 15",
        "att": "SELECT attack_category, COUNT(*) AS records FROM traffic GROUP BY attack_category ORDER BY records DESC",
    }
    res = {}
    for k, sql in q.items():
        log.info("Spark SQL [%s]: %s", k, sql)
        res[k] = spark.sql(sql).toPandas()
    total = int(res["total"].n.iloc[0])
    res["proto"]["pct"] = (res["proto"].records / total * 100).round(2)
    res["ports"]["malicious_pct"] = (res["ports"].malicious_connections / res["ports"].total_connections * 100).round(2)
    res["att"]["pct"] = (res["att"].records / total * 100).round(2)
    # Parquet output (Spark writes a directory of part files)
    spark.sql(q["att"]).write.mode("overwrite").parquet(str(ANALYTICS_DIR / "spark_analytics.parquet"))
    spark.stop()
    return total, res["proto"], res["src"], res["dst"], res["ports"], res["att"]


def _patterns(df):
    rows = []
    g = df.groupby("src_ip")
    uniq_ports = g["dst_port"].nunique()
    for ip, v in uniq_ports[uniq_ports >= 50].items():
        rows.append(("port_scan", ip, "source_ip", f"{v} distinct destination ports probed"))
    fails = g["failed_logins"].sum()
    for ip, v in fails[fails >= 20].items():
        rows.append(("brute_force", ip, "source_ip", f"{int(v)} failed logins"))
    ts = pd.to_datetime(df.timestamp)
    d = df.groupby(["dst_ip", ts.dt.floor("5min")])["src_ip"].nunique().reset_index(name="n").groupby("dst_ip").n.max()
    for ip, v in d[d >= 20].items():
        rows.append(("ddos_target", ip, "destination_ip", f"up to {v} distinct sources within a 5-minute window"))
    per_min = df.groupby(["src_ip", ts.dt.floor("min")]).size()
    burst = per_min[per_min >= 10].reset_index(name="n").groupby("src_ip").n.max()
    for ip, v in burst.items():
        rows.append(("connection_burst", ip, "source_ip", f"up to {v} connections within one minute"))
    tmp = df.assign(_t=ts)
    for (s, dd), grp in tmp.groupby(["src_ip", "dst_ip"]):
        if len(grp) >= 8:
            gaps = grp._t.sort_values().diff().dt.total_seconds().dropna()
            if 120 <= gaps.mean() <= 900 and gaps.std() / gaps.mean() < 0.15:
                rows.append(("beaconing", f"{s} -> {dd}", "src_dst_pair",
                             f"{len(grp)} connections, mean interval {gaps.mean():.0f}s (CV {gaps.std()/gaps.mean():.3f})"))
    return pd.DataFrame(rows, columns=["pattern", "entity", "entity_type", "evidence"])


def _volume(df):
    def s(col):
        x = df[col]
        return {"total": int(x.sum()), "mean": round(float(x.mean()), 2), "median": round(float(x.median()), 2),
                "p95": round(float(x.quantile(.95)), 2), "max": int(x.max())}
    return {"bytes_sent": s("bytes_sent"), "bytes_received": s("bytes_received"), "packets": s("packets"),
            "duration_seconds": {"mean": round(float(df.duration.mean()), 3), "median": round(float(df.duration.median()), 3),
                                 "p95": round(float(df.duration.quantile(.95)), 3), "max": round(float(df.duration.max()), 3)},
            "avg_bytes_sent_by_label": {k: round(float(v), 2) for k, v in df.groupby("label").bytes_sent.mean().items()}}


def run(df, log):
    engine = "pandas-fallback"
    out = None
    if os.environ.get("USE_SPARK", "1") == "1":
        try:
            out = _spark_core(log)
            engine = "pyspark"
        except Exception as e:  # ImportError, Java missing, etc.
            log.warning("Spark not usable (%s: %s) -> using documented pandas fallback", type(e).__name__, e)
    if out is None:
        out = _pandas_core(df)
    total, proto, src, dst, ports, att = out
    log.info("Analytics engine used: %s", engine)

    att["pct"] = att["pct"].astype(float)
    hourly = (df.assign(hour=pd.to_datetime(df.timestamp).dt.hour)
              .pivot_table(index="hour", columns="attack_category", values="record_id", aggfunc="count", fill_value=0)
              .reset_index())
    pats = _patterns(df)
    vol = _volume(df)

    tables = {"protocol_distribution": proto, "top_source_ips": src, "top_destination_ips": dst,
              "most_targeted_ports": ports, "attack_distribution": att,
              "attack_frequency_by_hour": hourly, "suspicious_patterns": pats}
    for name, t in tables.items():
        t.to_csv(ANALYTICS_DIR / f"{name}.csv", index=False)
        log.info("Wrote %s.csv (%d rows)", name, len(t))
    (ANALYTICS_DIR / "traffic_volume_stats.json").write_text(json.dumps(vol, indent=2))
    allres = {"engine": engine, "total_processed_records": int(total),
              **{k: json.loads(t.to_json(orient="records")) for k, t in tables.items()},
              "traffic_volume_stats": vol}
    (ANALYTICS_DIR / "analytics_results.json").write_text(json.dumps(allres, indent=2))
    log.info("Total processed records: %d | suspicious patterns found: %d", total, len(pats))
    if engine != "pyspark":
        log.info("spark_analytics.parquet NOT produced (Spark unavailable in this environment).")
    return allres
