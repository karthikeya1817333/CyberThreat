"""Central paths and constants."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
DATA_CSV = DATA_DIR / "network_traffic.csv"
RESULTS = ROOT / "results"
ANALYTICS_DIR = RESULTS / "analytics"
ML_DIR = RESULTS / "ml"
ANOMALY_DIR = RESULTS / "anomalies"
ALERT_DIR = RESULTS / "alerts"
VIZ_DIR = RESULTS / "visualizations"
MODEL_DIR = ROOT / "models"
LOG_DIR = ROOT / "logs"
SHOT_DIR = ROOT / "screenshots"

SEED = 42
CATEGORIES = ["Benign", "DDoS", "PortScan", "BruteForce", "Botnet", "SuspiciousBurst"]


def ensure_dirs():
    for d in (DATA_DIR, ANALYTICS_DIR, ML_DIR, ANOMALY_DIR, ALERT_DIR, VIZ_DIR,
              MODEL_DIR, LOG_DIR, SHOT_DIR):
        d.mkdir(parents=True, exist_ok=True)
