"""Feature engineering shared by Random Forest, Isolation Forest and alerting.

Uses only behavioural fields + per-entity aggregates. src_ip / dst_ip strings,
labels and attack_category are NEVER used as raw features.
"""
import numpy as np
import pandas as pd

FLAG_MAP = {"SYN": 0, "SYN-ACK": 1, "ACK": 2, "PSH-ACK": 3, "FIN": 4, "RST": 5, "NONE": 6}


def build_features(df):
    X = pd.DataFrame(index=df.index)
    for p in ("TCP", "UDP", "ICMP"):
        X[f"proto_{p}"] = (df.protocol == p).astype(int)
    X["flag_code"] = df["flags"].map(FLAG_MAP).fillna(6).astype(int)
    for c in ("src_port", "dst_port", "duration", "bytes_sent", "bytes_received", "packets", "failed_logins"):
        X[c] = df[c]
    X["bytes_per_packet"] = (df.bytes_sent + df.bytes_received) / df.packets
    X["packets_per_sec"] = df.packets / (df.duration + 0.01)
    minute = pd.to_datetime(df.timestamp).dt.floor("min")
    gs = df.groupby("src_ip")
    X["src_conn_count"] = gs["record_id"].transform("count")
    X["src_unique_dst_ports"] = gs["dst_port"].transform("nunique")
    X["src_unique_dsts"] = gs["dst_ip"].transform("nunique")
    X["src_failed_logins_total"] = gs["failed_logins"].transform("sum")
    X["src_conns_same_minute"] = df.groupby(["src_ip", minute])["record_id"].transform("count")
    gd = df.groupby("dst_ip")
    X["dst_conn_count"] = gd["record_id"].transform("count")
    X["dst_unique_srcs"] = gd["src_ip"].transform("nunique")
    X["dst_srcs_5min"] = df.groupby(["dst_ip", pd.to_datetime(df.timestamp).dt.floor("5min")])["src_ip"].transform("nunique")
    return X.astype(float)
