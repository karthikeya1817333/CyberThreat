"""Synthetic network-traffic generator (benign + 5 attack families).

The data is SYNTHETIC. Attack behaviours are modelled on well-known traffic
signatures, with deliberate overlap with benign traffic so classification is
not trivially perfect. Fully deterministic given SEED.
"""
import json
import numpy as np
import pandas as pd
from .config import DATA_CSV, ANALYTICS_DIR, SEED, ensure_dirs

BASE = pd.Timestamp("2026-11-01 00:00:00")
COUNTS = {"Benign": 8400, "DDoS": 1200, "PortScan": 900,
          "BruteForce": 600, "Botnet": 500, "SuspiciousBurst": 400}
COMMON_PORTS = [80, 443, 53, 22, 25, 3306, 123, 8080, 8443, 993]


def _pub_ips(rng, n):
    firsts = [23, 45, 66, 78, 91, 103, 142, 185, 203, 51, 89, 176]
    out = set()
    while len(out) < n:
        out.add(f"{rng.choice(firsts)}.{rng.integers(1, 255)}.{rng.integers(1, 255)}.{rng.integers(1, 255)}")
    return sorted(out)


def _int_ips(rng, n):
    out = set()
    while len(out) < n:
        out.add(f"192.168.{rng.integers(1, 5)}.{rng.integers(2, 250)}")
    return sorted(out)


def _frame(ts_sec, src, dst, sport, dport, proto, flags, dur, bs, br, pk, fl, cat):
    n = len(src)
    return pd.DataFrame({
        "timestamp": BASE + pd.to_timedelta(np.clip(ts_sec, 0, 86399.0), unit="s"),
        "src_ip": src, "dst_ip": dst, "src_port": sport, "dst_port": dport,
        "protocol": proto, "flags": flags,
        "duration": np.round(np.clip(dur, 0.0005, 600), 4),
        "bytes_sent": np.maximum(bs, 0).astype(int),
        "bytes_received": np.maximum(br, 0).astype(int),
        "packets": np.maximum(pk, 1).astype(int),
        "failed_logins": np.asarray(fl).astype(int),
        "attack_category": [cat] * n,
    })


def generate(seed=SEED):
    rng = np.random.default_rng(seed)
    servers = [f"10.0.1.{i}" for i in range(10, 70)]
    internal = _int_ips(rng, 300)
    ext_benign = _pub_ips(rng, 150)
    frames = []

    # ---- Benign (regular traffic; 830 of the benign records are look-alike "hard negatives" below)
    n = COUNTS["Benign"] - 830
    src_pool = internal + ext_benign
    w = np.r_[np.full(len(internal), 0.7 / len(internal)), np.full(len(ext_benign), 0.3 / len(ext_benign))]
    src = rng.choice(src_pool, n, p=w)
    dst = rng.choice(servers, n)
    dport = rng.choice(COMMON_PORTS, n, p=[.28, .30, .12, .06, .03, .04, .03, .06, .05, .03])
    proto = np.where(np.isin(dport, [53, 123]), np.where(rng.random(n) < .9, "UDP", "TCP"), "TCP")
    proto = np.where(rng.random(n) < .03, "ICMP", proto)
    dport = np.where(proto == "ICMP", 0, dport)
    flags = np.where(proto == "TCP", rng.choice(["ACK", "PSH-ACK", "FIN", "SYN-ACK"], n, p=[.4, .35, .15, .1]), "NONE")
    hours = np.where(rng.random(n) < .7, rng.uniform(8, 20, n), rng.uniform(0, 24, n))
    bs = rng.lognormal(6.5, 1.5, n); br = rng.lognormal(8.0, 1.8, n)
    pk = (bs + br) / rng.uniform(400, 1200, n)
    fl = np.where(np.isin(dport, [22, 3306]) & (rng.random(n) < .05), rng.integers(1, 3, n), 0)
    frames.append(_frame(hours * 3600, src, dst, rng.integers(1024, 65535, n), dport, proto, flags,
                         rng.lognormal(0.5, 1.2, n), bs, br, pk, fl, "Benign"))

    # ---- Benign look-alikes (hard negatives) -> 830 records
    def bf(ts, src, dst, dport, proto, flags, dur, bs, br, pk, fl):
        m = len(src)
        return _frame(np.asarray(ts, float), src, dst, rng.integers(1024, 65535, m), dport, proto, flags,
                      dur, bs, br, pk, fl, "Benign")
    # (a) monitoring agents: periodic heartbeats (look like botnet beaconing) -> 240
    for h in rng.choice(internal, 6, replace=False):
        k = 40; t0 = rng.uniform(0, 80000); sv = rng.choice(servers)
        frames.append(bf(t0 + np.arange(k) * 300 + rng.normal(0, 6, k), [h] * k, [sv] * k, np.full(k, 443),
                         ["TCP"] * k, rng.choice(["PSH-ACK", "ACK"], k), rng.uniform(5, 40, k),
                         rng.normal(350, 50, k), rng.normal(600, 80, k), rng.integers(5, 14, k), np.zeros(k)))
    # (b) authorised internal inventory scanners (look like port scans) -> 120
    for h in rng.choice(internal, 2, replace=False):
        k = 60; t0 = rng.uniform(0, 80000); sv = rng.choice(servers)
        frames.append(bf(t0 + rng.uniform(0, 1800, k), [h] * k, [sv] * k, rng.integers(1, 2001, k), ["TCP"] * k,
                         ["SYN"] * k, rng.lognormal(-5, .5, k), rng.integers(40, 90, k), rng.integers(0, 60, k),
                         rng.integers(1, 4, k), np.zeros(k)))
    # (c) backup / batch clients: bursts of big transfers (look like connection bursts) -> 120
    for h in rng.choice(internal, 8, replace=False):
        k = 15; t0 = rng.uniform(0, 85000); sv = rng.choice(servers)
        frames.append(bf(t0 + rng.uniform(0, 60, k), [h] * k, [sv] * k, rng.choice([22, 8080], k), ["TCP"] * k,
                         ["PSH-ACK"] * k, rng.lognormal(2.5, .6, k), rng.lognormal(11, .5, k),
                         rng.lognormal(9, .6, k), rng.integers(200, 900, k), np.zeros(k)))
    # (d) users mistyping passwords (look like brute force) -> 150
    for h in rng.choice(internal, 30, replace=False):
        k = 5; t0 = rng.uniform(0, 80000)
        frames.append(bf(t0 + rng.uniform(0, 7200, k), [h] * k, rng.choice(servers, k), rng.choice([22, 3389], k),
                         ["TCP"] * k, ["PSH-ACK"] * k, rng.uniform(1, 3, k), rng.lognormal(6, .4, k),
                         rng.lognormal(6, .4, k), rng.integers(8, 20, k), rng.integers(0, 5, k)))
    # (e) flash crowd: legitimate traffic spike to one server (looks like DDoS) -> 200
    k = 200; sv = rng.choice(servers)
    frames.append(bf(rng.uniform(11 * 3600, 11 * 3600 + 600, k), rng.choice(ext_benign, k), [sv] * k,
                     rng.choice([80, 443], k), ["TCP"] * k, rng.choice(["SYN-ACK", "ACK", "PSH-ACK"], k),
                     rng.lognormal(-1.5, .7, k), rng.lognormal(5.5, .8, k), rng.lognormal(8.5, 1, k),
                     rng.integers(4, 31, k), np.zeros(k)))

    # ---- DDoS: many spoofed sources -> 3 victims, two attack windows
    n = COUNTS["DDoS"]
    srcs = _pub_ips(rng, 400); victims = rng.choice(servers, 3, replace=False)
    win = np.where(rng.random(n) < .55, rng.uniform(2 * 3600, 2.5 * 3600, n), rng.uniform(14 * 3600, 14.75 * 3600, n))
    proto = rng.choice(["TCP", "UDP", "ICMP"], n, p=[.5, .35, .15])
    dport = np.where(proto == "ICMP", 0, rng.choice([80, 443, 53], n, p=[.5, .3, .2]))
    flags = np.where(proto == "TCP", np.where(rng.random(n) < .9, "SYN", "ACK"), "NONE")
    low = rng.random(n) < .35  # low-rate variants overlap benign
    dur = np.where(low, rng.lognormal(0, 1, n), rng.lognormal(-4, .8, n))
    pk = np.where(low, rng.integers(1, 10, n), rng.lognormal(3.5, .8, n))
    bs = np.where(low, rng.lognormal(6, 1, n), rng.lognormal(4.5, .6, n))
    frames.append(_frame(win, rng.choice(srcs, n), rng.choice(victims, n), rng.integers(1024, 65535, n), dport,
                         proto, flags, dur, bs, rng.lognormal(2, 1, n), pk, np.zeros(n), "DDoS"))

    # ---- PortScan: 15 scanners, wide port sweeps
    n = COUNTS["PortScan"]
    scanners = _pub_ips(rng, 15)
    per = np.array_split(np.arange(n), 15)
    src, ts, dst = [], [], []
    for k_, (s, idx) in enumerate(zip(scanners, per)):
        t0 = rng.uniform(0, 60000); tg = rng.choice(servers, rng.integers(1, 4), replace=False)
        span = 21600 if k_ < 4 else 1200            # first 4 scanners are slow scans
        src += [s] * len(idx); ts += list(t0 + rng.uniform(0, span, len(idx))); dst += list(rng.choice(tg, len(idx)))
    dport = np.where(rng.random(n) < .85, rng.integers(1, 10001, n), rng.choice(COMMON_PORTS, n))
    proto = np.where(rng.random(n) < .9, "TCP", "UDP")
    flags = np.where(proto == "TCP", rng.choice(["SYN", "RST", "FIN"], n, p=[.8, .1, .1]), "NONE")
    frames.append(_frame(np.array(ts), np.array(src), np.array(dst), rng.integers(1024, 65535, n), dport, proto,
                         flags, rng.lognormal(-5, .5, n), rng.integers(40, 90, n), rng.integers(0, 60, n),
                         rng.integers(1, 4, n), np.zeros(n), "PortScan"))

    # ---- BruteForce: 20 attackers vs auth services
    n = COUNTS["BruteForce"]
    atk = _pub_ips(rng, 20); tg = rng.choice(servers, 5, replace=False)
    per = np.array_split(np.arange(n), 20)
    src, ts, fl = [], [], []
    for k_, (a, idx) in enumerate(zip(atk, per)):
        t0 = rng.uniform(0, 60000); slow = k_ < 5   # first 5 attackers are low-and-slow
        src += [a] * len(idx); ts += list(t0 + rng.uniform(0, 21600 if slow else 2400, len(idx)))
        fl += list(rng.integers(1, 4, len(idx)) if slow else np.where(rng.random(len(idx)) < .1, 1, rng.integers(2, 26, len(idx))))
    fl = np.array(fl)
    dport = rng.choice([22, 3389, 21, 23], n, p=[.55, .2, .15, .1])
    frames.append(_frame(np.array(ts), np.array(src), rng.choice(tg, n), rng.integers(1024, 65535, n), dport,
                         ["TCP"] * n, rng.choice(["PSH-ACK", "ACK"], n, p=[.7, .3]), rng.uniform(.3, 4, n),
                         rng.lognormal(6, .4, n), rng.lognormal(6, .4, n), rng.integers(8, 26, n), fl, "BruteForce"))

    # ---- Botnet: periodic beaconing from infected internal hosts to C2
    n = COUNTS["Botnet"]
    bots = rng.choice(internal, 40, replace=False); c2 = _pub_ips(rng, 5)
    per = np.array_split(np.arange(n), 40)
    src, dst, ts = [], [], []
    for k_, (b, idx) in enumerate(zip(bots, per)):
        t0 = rng.uniform(0, 70000); c = rng.choice(c2)
        src += [b] * len(idx); dst += [c] * len(idx)
        ts += list(t0 + np.arange(len(idx)) * 300 + rng.normal(0, 60 if k_ < 10 else 8, len(idx)))  # 10 jittery bots
    dport = rng.choice([4444, 6667, 8443, 1337, 443, 8080], n, p=[.2, .2, .15, .1, .2, .15])
    blend = rng.random(n) < .15                       # some beacons blend into normal-looking HTTPS
    dport = np.where(blend, 443, dport)
    proto = np.where(rng.random(n) < .85, "TCP", "UDP")
    frames.append(_frame(np.array(ts), np.array(src), np.array(dst), rng.integers(1024, 65535, n), dport, proto,
                         np.where(proto == "TCP", rng.choice(["PSH-ACK", "ACK"], n), "NONE"),
                         np.where(blend, rng.lognormal(1, 1, n), rng.uniform(20, 120, n)),
                         np.where(blend, rng.lognormal(6.5, 1, n), rng.normal(300, 40, n)),
                         np.where(blend, rng.lognormal(8, 1.5, n), rng.normal(500, 60, n)),
                         rng.integers(6, 15, n), np.zeros(n), "Botnet"))

    # ---- SuspiciousBurst: short bursts of varied connections (heavily overlaps benign)
    n = COUNTS["SuspiciousBurst"]
    bsrc = internal[:8] + _pub_ips(rng, 17)
    sizes = 8 + rng.multinomial(n - 8 * 25, [1 / 25] * 25)      # bursts of 8..~24 records
    src, ts = [], []
    for s, sz in zip(bsrc, sizes):
        t0 = rng.uniform(0, 85000); src += [s] * int(sz); ts += list(t0 + rng.uniform(0, 120, int(sz)))
    dport = np.where(rng.random(n) < .8, rng.choice(COMMON_PORTS + [21, 23, 3389, 5900], n), rng.integers(1024, 65535, n))
    frames.append(_frame(np.array(ts), np.array(src), rng.choice(servers, n), rng.integers(1024, 65535, n), dport,
                         ["TCP"] * n, rng.choice(["SYN", "ACK", "PSH-ACK", "RST"], n), rng.lognormal(-1, 1, n),
                         rng.lognormal(6, 1, n), rng.lognormal(6, 1, n), rng.integers(3, 21, n),
                         rng.integers(0, 3, n), "SuspiciousBurst"))

    df = pd.concat(frames, ignore_index=True).sort_values("timestamp", kind="stable").reset_index(drop=True)
    df.insert(0, "record_id", np.arange(1, len(df) + 1))
    df["label"] = np.where(df["attack_category"] == "Benign", "Benign", "Malicious")
    df["timestamp"] = df["timestamp"].dt.strftime("%Y-%m-%d %H:%M:%S")
    return df


def dataset_summary(df):
    return {
        "total_records": int(len(df)),
        "benign_records": int((df.label == "Benign").sum()),
        "malicious_records": int((df.label == "Malicious").sum()),
        "attack_category_distribution": {k: int(v) for k, v in df.attack_category.value_counts().items()},
        "unique_source_ips": int(df.src_ip.nunique()),
        "unique_destination_ips": int(df.dst_ip.nunique()),
        "time_range": {"start": df.timestamp.min(), "end": df.timestamp.max()},
        "note": "Synthetic dataset generated by src/generate_dataset.py (deterministic seed).",
    }


def run(log):
    ensure_dirs()
    df = generate()
    df.to_csv(DATA_CSV, index=False)
    summ = dataset_summary(df)
    (ANALYTICS_DIR / "dataset_summary.json").write_text(json.dumps(summ, indent=2))
    log.info("Dataset written: %s (%d records)", DATA_CSV, len(df))
    log.info("Dataset summary: %s", json.dumps(summ))
    return df
