"""Random Forest (multi-class) + Isolation Forest (unsupervised). All metrics are computed, never typed."""
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, IsolationForest
from sklearn.metrics import (accuracy_score, precision_recall_fscore_support, confusion_matrix,
                             classification_report)
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.preprocessing import StandardScaler
from .config import ML_DIR, ANOMALY_DIR, MODEL_DIR, SEED, CATEGORIES
from .features import build_features

RF_PARAMS = dict(n_estimators=200, class_weight="balanced", random_state=SEED, n_jobs=-1)
IF_PARAMS = dict(n_estimators=200, contamination=0.10, random_state=SEED, n_jobs=-1)


RECORD_LEVEL = ["proto_TCP", "proto_UDP", "proto_ICMP", "flag_code", "src_port", "dst_port", "duration",
                "bytes_sent", "bytes_received", "packets", "failed_logins", "bytes_per_packet", "packets_per_sec"]


def group_cv(n_splits=5):
    """Stratified, source-IP-grouped folds: a source IP never appears in both train and test."""
    return StratifiedGroupKFold(n_splits=n_splits, shuffle=True, random_state=SEED)


def holdout_split(df):
    tr, te = next(group_cv().split(df, df.attack_category, groups=df.src_ip))
    return df.index[tr], df.index[te]


def train_random_forest(df, X, log):
    y = df.attack_category
    idx_tr, idx_te = holdout_split(df)
    assert set(df.loc[idx_tr, "src_ip"]).isdisjoint(set(df.loc[idx_te, "src_ip"])), "source-IP leakage"
    rf = RandomForestClassifier(**RF_PARAMS).fit(X.loc[idx_tr], y.loc[idx_tr])
    # ablation: record-level features only (no per-IP aggregates)
    rf_rl = RandomForestClassifier(**RF_PARAMS).fit(X.loc[idx_tr, RECORD_LEVEL], y.loc[idx_tr])
    pred_rl = rf_rl.predict(X.loc[idx_te, RECORD_LEVEL])
    pred = rf.predict(X.loc[idx_te])
    proba = rf.predict_proba(X.loc[idx_te])
    yt = y.loc[idx_te]
    labels = [c for c in CATEGORIES if c in rf.classes_]

    acc = accuracy_score(yt, pred)
    pw, rw, fw, _ = precision_recall_fscore_support(yt, pred, average="weighted", zero_division=0)
    pm, rm, fm, _ = precision_recall_fscore_support(yt, pred, average="macro", zero_division=0)
    pc, rc, fc, sc = precision_recall_fscore_support(yt, pred, labels=labels, zero_division=0)
    cm = confusion_matrix(yt, pred, labels=labels)
    # derived binary view: Benign vs Malicious
    yb, pb = (yt != "Benign"), (pred != "Benign")
    bp, br, bf, _ = precision_recall_fscore_support(yb, pb, average="binary", zero_division=0)

    metrics = {
        "model": "RandomForestClassifier", "task": "multi-class attack category",
        "params": {**RF_PARAMS, "n_jobs": -1},
        "train_records": int(len(idx_tr)), "test_records": int(len(idx_te)),
        "accuracy": acc,
        "weighted": {"precision": pw, "recall": rw, "f1": fw},
        "macro": {"precision": pm, "recall": rm, "f1": fm},
        "per_class": {l: {"precision": float(pc[i]), "recall": float(rc[i]), "f1": float(fc[i]), "support": int(sc[i])}
                      for i, l in enumerate(labels)},
        "binary_benign_vs_malicious": {"precision": bp, "recall": br, "f1": bf,
                                       "accuracy": float(accuracy_score(yb, pb))},
        "feature_importances_top10": dict(sorted(zip(X.columns, map(float, rf.feature_importances_)),
                                                 key=lambda kv: -kv[1])[:10]),
        "ablation_record_level_features_only": {
            "features": RECORD_LEVEL,
            "accuracy": float(accuracy_score(yt, pred_rl)),
            "weighted_f1": float(precision_recall_fscore_support(yt, pred_rl, average="weighted", zero_division=0)[2]),
            "macro_f1": float(precision_recall_fscore_support(yt, pred_rl, average="macro", zero_division=0)[2])},
        "split": "StratifiedGroupKFold (first of 5 folds, ~20% test) grouped by src_ip: no source IP appears in both train and test.",
        "evaluation_note": "Metrics are from actual execution on SYNTHETIC data; attack patterns are cleanly separable, so high scores do not imply real-world performance.",
    }
    for k in ("accuracy",):
        metrics[k] = float(metrics[k])
    for g in ("weighted", "macro", "binary_benign_vs_malicious"):
        metrics[g] = {k: float(v) for k, v in metrics[g].items()}
    (ML_DIR / "model_metrics.json").write_text(json.dumps(metrics, indent=2))
    (ML_DIR / "classification_report.txt").write_text(
        classification_report(yt, pred, labels=labels, digits=4, zero_division=0))
    pd.DataFrame(cm, index=[f"actual_{l}" for l in labels], columns=[f"pred_{l}" for l in labels]
                 ).to_csv(ML_DIR / "confusion_matrix.csv")
    te = df.loc[idx_te, ["record_id", "timestamp", "src_ip", "dst_ip", "protocol", "dst_port"]].copy()
    te["actual_category"] = yt.values; te["predicted_category"] = pred
    te["confidence"] = proba.max(axis=1).round(4); te["correct"] = (te.actual_category == te.predicted_category)
    te.sample(100, random_state=SEED).sort_values("record_id").to_csv(ML_DIR / "sample_predictions.csv", index=False)
    pd.Series(sorted(df.loc[idx_te, "record_id"].tolist()), name="record_id").to_csv(
        MODEL_DIR / "test_split_record_ids.csv", index=False)
    joblib.dump(rf, MODEL_DIR / "random_forest.joblib")
    log.info("RF accuracy=%.4f weighted P/R/F1=%.4f/%.4f/%.4f | binary recall=%.4f",
             acc, pw, rw, fw, br)
    log.info("Classification report:\n%s", (ML_DIR / "classification_report.txt").read_text())
    log.info("Confusion matrix:\n%s", pd.read_csv(ML_DIR / "confusion_matrix.csv", index_col=0).to_string())
    return rf, metrics


def run_isolation_forest(df, X, log):
    Xl = X.copy()
    for c in ("duration", "bytes_sent", "bytes_received", "packets", "bytes_per_packet", "packets_per_sec",
              "src_conn_count", "dst_conn_count", "src_failed_logins_total"):
        Xl[c] = np.log1p(Xl[c])
    Z = StandardScaler().fit_transform(Xl)
    iso = IsolationForest(**IF_PARAMS).fit(Z)
    raw = -iso.score_samples(Z)                       # higher = more anomalous
    norm = (raw - raw.min()) / (raw.max() - raw.min())
    is_anom = iso.predict(Z) == -1
    out = df[["record_id", "timestamp", "src_ip", "dst_ip", "protocol", "dst_port", "bytes_sent", "packets",
              "attack_category"]].copy()
    out["anomaly_score"] = np.round(norm, 5); out["raw_score"] = np.round(raw, 5); out["is_anomaly"] = is_anom
    det = out[out.is_anomaly].sort_values("anomaly_score", ascending=False)
    det.to_csv(ANOMALY_DIR / "detected_anomalies.csv", index=False)
    n_an = int(is_anom.sum())
    summ = {
        "model": "IsolationForest", "params": IF_PARAMS,
        "total_records": int(len(df)), "total_anomalies_detected": n_an,
        "normal_traffic_count": int(len(df) - n_an),
        "anomaly_percentage": round(n_an / len(df) * 100, 3),
        "anomaly_score_stats": {"min": float(norm.min()), "mean": float(norm.mean()), "max": float(norm.max())},
        "anomalies_by_attack_category": {k: int(v) for k, v in det.attack_category.value_counts().items()},
        "top_10_suspicious_records": json.loads(det.head(10).to_json(orient="records")),
        "ground_truth_check": {
            "note": "Labels were NOT used for training; used here only to evaluate the unsupervised detector.",
            "share_of_anomalies_that_are_malicious": round(float((det.attack_category != "Benign").mean()), 4),
            "share_of_malicious_records_flagged": round(float(
                det.attack_category.ne("Benign").sum() / (df.label == "Malicious").sum()), 4)},
        "contamination_note": "contamination=0.10 is a configured assumption, so anomaly_percentage is close to 10% by design.",
    }
    (ANOMALY_DIR / "anomaly_summary.json").write_text(json.dumps(summ, indent=2))
    log.info("IsolationForest: %d anomalies (%.2f%%), %d normal", n_an, summ["anomaly_percentage"], len(df) - n_an)
    log.info("Ground-truth check: %s", json.dumps(summ["ground_truth_check"]))
    return out
