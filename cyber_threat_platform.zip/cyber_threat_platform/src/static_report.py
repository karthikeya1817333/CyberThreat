"""Static HTML rendering of the SAME result files the Streamlit dashboard reads.

Purpose: (1) offline viewing, (2) a screenshot source in environments where Streamlit cannot be run.
This is NOT the Streamlit UI; screenshots taken from it are labelled accordingly.
"""
import base64
import html
from .config import VIZ_DIR, RESULTS, SHOT_DIR
from dashboard import loaders


def _img(name):
    b = (VIZ_DIR / name).read_bytes()
    return f'<img src="data:image/png;base64,{base64.b64encode(b).decode()}" alt="{name}">'


def _tbl(df, n=15):
    return df.head(n).to_html(index=False, border=0, classes="t", float_format=lambda x: f"{x:,.4f}".rstrip("0").rstrip("."))


def build():
    D = loaders.load_all()
    S, M, AN, SV, AL = D["summary"], D["metrics"], D["anom"], D["sev"], D["alerts"]
    kpi = [("Total traffic processed", f"{S['total_records']:,}"), ("Benign", f"{S['benign_records']:,}"),
           ("Malicious", f"{S['malicious_records']:,}"), ("RF accuracy (hold-out)", f"{M['accuracy']:.4f}"),
           ("Anomalies (Isolation Forest)", f"{AN['total_anomalies_detected']:,}"), ("Alerts", f"{SV['total_alerts']:,}")]
    cards = "".join(f'<div class="k"><div class="v">{v}</div><div class="l">{l}</div></div>' for l, v in kpi)
    sevc = "".join(f'<div class="k s-{n}"><div class="v">{SV[n]:,}</div><div class="l">{n.capitalize()}</div></div>'
                   for n in ("critical", "high", "medium", "low"))
    mc = "".join(f'<div class="k"><div class="v">{v:.4f}</div><div class="l">{l}</div></div>' for l, v in
                 [("Accuracy", M["accuracy"]), ("Precision (weighted)", M["weighted"]["precision"]),
                  ("Recall (weighted)", M["weighted"]["recall"]), ("F1 (weighted)", M["weighted"]["f1"])])
    return f"""<!doctype html><html><head><meta charset="utf-8"><title>Cyber Threat Report (static)</title>
<style>body{{font-family:Segoe UI,Arial,sans-serif;margin:0;background:#f4f6f8;color:#1b2a35}}
header{{background:#12263a;color:#fff;padding:18px 32px}} main{{padding:20px 32px;max-width:1400px;margin:auto}}
section{{background:#fff;border-radius:8px;padding:16px 20px;margin-bottom:18px;box-shadow:0 1px 3px #0002}}
.row{{display:flex;gap:12px;flex-wrap:wrap}} .k{{flex:1;min-width:150px;background:#eef3f8;border-radius:8px;padding:12px;text-align:center}}
.v{{font-size:26px;font-weight:700}} .l{{font-size:12px;color:#556}} .grid{{display:flex;flex-wrap:wrap;gap:14px}} img{{max-width:100%;height:auto}}
.t{{border-collapse:collapse;font-size:12px}} .t th,.t td{{padding:4px 8px;border-bottom:1px solid #e3e8ee;text-align:left}}
.t th{{background:#e9eef4}} pre{{background:#0f1c27;color:#d6e4f0;padding:12px;border-radius:6px;overflow:auto;font-size:12px}}
.s-critical .v{{color:#9b2226}}.s-high .v{{color:#d9480f}}.s-medium .v{{color:#b08900}}.s-low .v{{color:#2f7d32}}
.banner{{background:#fff3cd;padding:8px 32px;font-size:13px}}</style></head><body>
<header><h2 style="margin:0">Cybersecurity Threat Detection – Results Report</h2>
<div style="font-size:13px;opacity:.8">Engine: {D['analytics']['engine']} · synthetic data</div></header>
<div class="banner">Static HTML rendering of the generated result files. The interactive dashboard is <code>dashboard/app.py</code> (Streamlit).</div>
<main>
<section id="overview"><h3>Overview</h3><div class="row">{cards}</div>
<div class="grid">{_img('attack_distribution.png')}{_img('protocol_distribution.png')}</div></section>
<section id="traffic"><h3>Top source / destination IPs</h3><div class="grid"><div>{_tbl(D['top_src'])}</div><div>{_tbl(D['top_dst'])}</div></div>
<h3>Most targeted ports</h3>{_tbl(D['ports'])}<h3>Suspicious traffic patterns ({len(D['patterns'])} found)</h3>{_tbl(D['patterns'], 12)}</section>
<section id="ml"><h3>Random Forest performance</h3><div class="row">{mc}</div>
<div class="grid">{_img('confusion_matrix.png')}{_img('per_class_metrics.png')}{_img('feature_importance.png')}</div>
<pre>{html.escape(D['report_txt'])}</pre></section>
<section id="anomalies"><h3>Isolation Forest</h3><div class="row">
<div class="k"><div class="v">{AN['total_anomalies_detected']:,}</div><div class="l">Anomalies</div></div>
<div class="k"><div class="v">{AN['normal_traffic_count']:,}</div><div class="l">Normal</div></div>
<div class="k"><div class="v">{AN['anomaly_percentage']:.2f}%</div><div class="l">Anomaly %</div></div></div>
{_img('anomaly_scores.png')}<h4>Top suspicious records</h4>{_tbl(D['anom_df'][['record_id','timestamp','src_ip','dst_ip','protocol','dst_port','anomaly_score','attack_category']], 10)}</section>
<section id="alerts"><h3>Security alerts</h3><div class="row">{sevc}</div>{_img('severity_distribution.png')}
<h4>Top suspicious IP addresses</h4>{_tbl(loaders.suspicious_ips(AL))}
<h4>Highest-scoring alerts</h4>{_tbl(AL[['alert_id','timestamp','src_ip','dst_ip','protocol','attack_category','threat_score','severity','detection_reason']], 15)}</section>
</main></body></html>"""


def screenshot(html_path, log):
    try:
        from playwright.sync_api import sync_playwright
    except Exception as e:
        log.warning("Playwright unavailable (%s); screenshots skipped", e); return []
    SHOT_DIR.mkdir(exist_ok=True)
    out = []
    with sync_playwright() as p:
        b = p.chromium.launch(); pg = b.new_page(viewport={"width": 1440, "height": 900})
        pg.goto(html_path.as_uri())
        pg.screenshot(path=str(SHOT_DIR / "01_full_report_static.png"), full_page=True); out.append("01_full_report_static.png")
        for i, sid in enumerate(["overview", "ml", "anomalies", "alerts"], start=2):
            f = f"{i:02d}_{sid}_static.png"
            pg.locator(f"#{sid}").screenshot(path=str(SHOT_DIR / f)); out.append(f)
        b.close()
    return out


def run(log):
    out = RESULTS / "dashboard_static"; out.mkdir(parents=True, exist_ok=True)
    f = out / "dashboard_static.html"; f.write_text(build(), encoding="utf-8")
    log.info("Static HTML report written: %s", f)
    shots = screenshot(f, log)
    log.info("Screenshots (of the STATIC HTML rendering, not Streamlit): %s", shots)
