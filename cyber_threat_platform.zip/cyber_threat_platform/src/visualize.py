"""Charts rendered from the generated result files (not from in-memory literals)."""
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from .config import ANALYTICS_DIR, ML_DIR, ANOMALY_DIR, ALERT_DIR, VIZ_DIR


def run(log):
    VIZ_DIR.mkdir(parents=True, exist_ok=True)
    # confusion matrix
    cm = pd.read_csv(ML_DIR / "confusion_matrix.csv", index_col=0)
    fig, ax = plt.subplots(figsize=(7, 6))
    im = ax.imshow(cm.values, cmap="Blues")
    ax.set_xticks(range(len(cm.columns))); ax.set_xticklabels([c[5:] for c in cm.columns], rotation=35, ha="right")
    ax.set_yticks(range(len(cm.index))); ax.set_yticklabels([c[7:] for c in cm.index])
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(j, i, int(cm.values[i, j]), ha="center", va="center",
                    color="white" if cm.values[i, j] > cm.values.max() / 2 else "black")
    ax.set_xlabel("Predicted"); ax.set_ylabel("Actual"); ax.set_title("Random Forest – Confusion Matrix (hold-out test set)")
    fig.colorbar(im); fig.tight_layout(); fig.savefig(VIZ_DIR / "confusion_matrix.png", dpi=130); plt.close(fig)

    att = pd.read_csv(ANALYTICS_DIR / "attack_distribution.csv")
    fig, ax = plt.subplots(figsize=(8, 4.5))
    bars = ax.bar(att.attack_category, att.records, color=plt.cm.tab10.colors[:len(att)])
    ax.bar_label(bars); ax.set_title("Traffic by Attack Category"); ax.set_ylabel("Records")
    plt.setp(ax.get_xticklabels(), rotation=25, ha="right"); fig.tight_layout()
    fig.savefig(VIZ_DIR / "attack_distribution.png", dpi=130); plt.close(fig)

    m = json.loads((ML_DIR / "model_metrics.json").read_text())
    fi = pd.Series(m["feature_importances_top10"]).sort_values()
    fig, ax = plt.subplots(figsize=(7.5, 4.5)); ax.barh(fi.index, fi.values, color="#2a6f97")
    ax.set_title("Random Forest – Top 10 Feature Importances"); fig.tight_layout()
    fig.savefig(VIZ_DIR / "feature_importance.png", dpi=130); plt.close(fig)

    pc = pd.DataFrame(m["per_class"]).T[["precision", "recall", "f1"]]
    fig, ax = plt.subplots(figsize=(8.5, 4.5)); pc.plot.bar(ax=ax, ylim=(0, 1.05))
    ax.set_title("Random Forest – Per-class Precision / Recall / F1"); plt.setp(ax.get_xticklabels(), rotation=25, ha="right")
    fig.tight_layout(); fig.savefig(VIZ_DIR / "per_class_metrics.png", dpi=130); plt.close(fig)

    al = pd.read_csv(ALERT_DIR / "security_alerts.csv")
    order = ["Critical", "High", "Medium", "Low"]
    sc = al.severity.value_counts().reindex(order).fillna(0)
    fig, ax = plt.subplots(figsize=(6.5, 4.2))
    bars = ax.bar(sc.index, sc.values, color=["#9b2226", "#ee6c4d", "#e9c46a", "#8ab17d"])
    ax.bar_label(bars); ax.set_title("Alert Severity Distribution"); fig.tight_layout()
    fig.savefig(VIZ_DIR / "severity_distribution.png", dpi=130); plt.close(fig)

    an = pd.read_csv(ANOMALY_DIR / "detected_anomalies.csv")
    fig, ax = plt.subplots(figsize=(7.5, 4.2)); ax.hist(an.anomaly_score, bins=40, color="#6a4c93")
    ax.set_title("Isolation Forest – Anomaly Score Distribution (detected anomalies)")
    ax.set_xlabel("Normalized anomaly score"); fig.tight_layout()
    fig.savefig(VIZ_DIR / "anomaly_scores.png", dpi=130); plt.close(fig)

    pr = pd.read_csv(ANALYTICS_DIR / "protocol_distribution.csv")
    fig, ax = plt.subplots(figsize=(5.5, 5)); ax.pie(pr.records, labels=pr.protocol, autopct="%1.1f%%")
    ax.set_title("Protocol Distribution"); fig.tight_layout()
    fig.savefig(VIZ_DIR / "protocol_distribution.png", dpi=130); plt.close(fig)
    log.info("Visualizations written to %s: %s", VIZ_DIR, sorted(p.name for p in VIZ_DIR.glob("*.png")))
