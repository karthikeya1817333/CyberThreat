#!/usr/bin/env python3
"""Executes dashboard/app.py against the REAL results files using a recording STUB of the `streamlit` module.
This proves app.py runs without errors and that every KPI it renders equals the generated files.
It is NOT a substitute for launching the real Streamlit server (`streamlit run dashboard/app.py`)."""
import json
import runpy
import sys
import types
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CALLS = []


class Node:
    def __enter__(self): return self
    def __exit__(self, *a): return False
    def __getattr__(self, name):
        def f(*a, **k):
            CALLS.append((name, a, k))
            if name in ("columns",):
                n = a[0] if isinstance(a[0], int) else len(a[0]); return [Node() for _ in range(n)]
            if name == "tabs": return [Node() for _ in a[0]]
            if name == "multiselect": return k.get("default", a[1])
            if name == "slider": return a[1]
            return None
        return f


st = Node()
mod = types.ModuleType("streamlit")
mod.__getattr__ = lambda name: (lambda fn: fn) if name == "cache_data" else getattr(st, name)
sys.modules["streamlit"] = mod
sys.path.insert(0, str(ROOT))
runpy.run_path(str(ROOT / "dashboard/app.py"), run_name="__main__")

R = ROOT / "results"
S = json.loads((R / "analytics/dataset_summary.json").read_text())
M = json.loads((R / "ml/model_metrics.json").read_text())
SV = json.loads((R / "alerts/severity_summary.json").read_text())
metrics = {a[0]: a[1] for n, a, k in CALLS if n == "metric"}
ok = True
def chk(name, cond):
    global ok; ok &= bool(cond); print(f"[{'PASS' if cond else 'FAIL'}] {name}")
chk("app ran to completion without exception", True)
chk("KPI 'Total traffic processed' == dataset_summary", metrics.get("Total traffic processed") == f"{S['total_records']:,}")
chk("KPI 'Malicious' == dataset_summary", metrics.get("Malicious") == f"{S['malicious_records']:,}")
chk("KPI 'RF accuracy (test)' == model_metrics.json", metrics.get("RF accuracy (test)") == f"{M['accuracy']:.4f}")
chk("KPI 'Critical' == severity_summary", metrics.get("Critical") == f"{SV['critical']:,}")
chk("download buttons rendered (>=7)", sum(1 for n, *_ in CALLS if n == "download_button") >= 7)
chk("interactive alert table rendered", any(n == "dataframe" for n, *_ in CALLS) and any(n == "multiselect" for n, *_ in CALLS))
chk("charts rendered (>=6 bar charts)", sum(1 for n, *_ in CALLS if n == "bar_chart") >= 6)
print(f"streamlit calls recorded: {len(CALLS)}")
sys.exit(0 if ok else 1)
