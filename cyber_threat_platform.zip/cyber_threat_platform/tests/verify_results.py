#!/usr/bin/env python3
"""Independent verification of generated results. Exit code 0 only if every check passes.
Recomputes model metrics from the saved model + data and compares them with model_metrics.json."""
import json
import sys
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, confusion_matrix

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from src.features import build_features  # noqa: E402
from dashboard import loaders  # noqa: E402

R = ROOT / "results"
fails, lines = [], []


def check(name, ok, detail=""):
    lines.append(f"[{'PASS' if ok else 'FAIL'}] {name} {detail}")
    if not ok:
        fails.append(name)


REQ = ["analytics/dataset_summary.json", "analytics/protocol_distribution.csv", "analytics/top_source_ips.csv",
       "analytics/top_destination_ips.csv", "analytics/attack_distribution.csv", "analytics/most_targeted_ports.csv",
       "analytics/suspicious_patterns.csv", "analytics/traffic_volume_stats.json", "analytics/analytics_results.json",
       "ml/model_metrics.json", "ml/classification_report.txt", "ml/confusion_matrix.csv", "ml/sample_predictions.csv",
       "anomalies/anomaly_summary.json", "anomalies/detected_anomalies.csv",
       "alerts/security_alerts.csv", "alerts/severity_summary.json",
       "visualizations/confusion_matrix.png", "visualizations/attack_distribution.png"]
# 1 files exist & non-empty
for f in REQ:
    p = R / f
    check(f"exists+nonempty {f}", p.exists() and p.stat().st_size > 0)
# 2 CSVs contain records
for p in sorted(R.rglob("*.csv")):
    n = len(pd.read_csv(p))
    check(f"csv has records {p.relative_to(R)}", n > 0, f"({n} rows)")
# 3 JSON valid
for p in sorted(R.rglob("*.json")):
    try:
        ok = bool(json.loads(p.read_text()))
    except Exception:
        ok = False
    check(f"json valid {p.relative_to(R)}", ok)
# 4 dataset
df = pd.read_csv(ROOT / "data" / "network_traffic.csv")
S = json.loads((R / "analytics/dataset_summary.json").read_text())
check("dataset >= 10,000 records", len(df) >= 10000, f"({len(df)})")
check("dataset_summary matches CSV", S["total_records"] == len(df) and S["benign_records"] == int((df.label == "Benign").sum())
      and S["unique_source_ips"] == df.src_ip.nunique() and S["unique_destination_ips"] == df.dst_ip.nunique())
check("all attack categories present", set(df.attack_category) >= {"Benign", "DDoS", "PortScan", "BruteForce", "Botnet", "SuspiciousBurst"})
# 5 model metrics == recomputation from saved model
M = json.loads((R / "ml/model_metrics.json").read_text())
rf = joblib.load(ROOT / "models/random_forest.joblib")
X = build_features(df)
ids = set(pd.read_csv(ROOT / "models/test_split_record_ids.csv").record_id)
te = df.record_id.isin(ids)
check("test split size matches metrics", int(te.sum()) == M["test_records"])
check("no source-IP overlap train/test", set(df.loc[te, "src_ip"]).isdisjoint(set(df.loc[~te, "src_ip"])))
pred = rf.predict(X[te])
acc = accuracy_score(df.attack_category[te], pred)
check("recomputed accuracy == model_metrics.json", abs(acc - M["accuracy"]) < 1e-12, f"({acc:.6f})")
cm_saved = pd.read_csv(R / "ml/confusion_matrix.csv", index_col=0)
labels = [c[5:] for c in cm_saved.columns]
cm = confusion_matrix(df.attack_category[te], pred, labels=labels)
check("recomputed confusion matrix == saved", (cm == cm_saved.values).all())
check("confusion matrix sums to test size", int(cm_saved.values.sum()) == M["test_records"])
# 6 anomalies
A = json.loads((R / "anomalies/anomaly_summary.json").read_text())
an = pd.read_csv(R / "anomalies/detected_anomalies.csv")
check("anomaly count matches CSV", A["total_anomalies_detected"] == len(an))
check("anomaly+normal == total", A["total_anomalies_detected"] + A["normal_traffic_count"] == len(df))
# 7 alerts
al = pd.read_csv(R / "alerts/security_alerts.csv")
SV = json.loads((R / "alerts/severity_summary.json").read_text())
need = ["alert_id", "timestamp", "src_ip", "dst_ip", "protocol", "attack_category", "threat_score", "severity", "detection_reason"]
check("alert columns present", all(c in al.columns for c in need))
check("alerts have no empty required fields", not al[need].isna().any().any())
vc = al.severity.value_counts()
check("severity_summary matches alerts CSV", all(SV[k.lower()] == int(vc.get(k, 0)) for k in ("Critical", "High", "Medium", "Low"))
      and SV["total_alerts"] == len(al))
check("alert IDs unique", al.alert_id.is_unique)
# 8 dashboard data layer
check("dashboard loaders: no missing files", loaders.missing_files() == [])
D = loaders.load_all()
check("dashboard reads same totals as files", D["summary"]["total_records"] == len(df) and D["metrics"]["accuracy"] == M["accuracy"])
# 9 optional spark
pq = R / "analytics/spark_analytics.parquet"
eng = json.loads((R / "analytics/analytics_results.json").read_text())["engine"]
check("engine/parquet consistent", (eng == "pyspark") == pq.exists(), f"(engine={eng}, parquet_exists={pq.exists()})")

print("\n".join(lines))
print(f"\n{len(lines) - len(fails)}/{len(lines)} checks passed")
(ROOT / "logs").mkdir(exist_ok=True)
(ROOT / "logs/verification.log").write_text("\n".join(lines) + f"\n\n{len(lines) - len(fails)}/{len(lines)} checks passed\n")
sys.exit(1 if fails else 0)
